Some of the icons used are from the FAMFAMFAM Silk Icon Collection (http://www.famfamfam.com/lab/icons/silk/)
and are licensed under Creative Commons Attribution 2.5 License.
Some of the icons used are from Fugue Icons (http://p.yusukekamiyamane.com/icons/downloads/fugue-icons-3.5.6.zip)
and are licensed under Creative Commons Attribution 3.0 License.
